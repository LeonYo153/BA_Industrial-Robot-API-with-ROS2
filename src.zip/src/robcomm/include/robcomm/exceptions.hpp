/** \file exceptions.hpp
 * \brief Exceptions for librobcomm.
 *
 * Created on: 27.03.2023
 * Author: Bernhard Vorhofer
 * Contributor: -
 */

#ifndef ROBCOMM_EXCEPTIONS_H
#define ROBCOMM_EXCEPTIONS_H

namespace robcomm {

}

#endif // ROBCOMM_EXCEPTIONS_H