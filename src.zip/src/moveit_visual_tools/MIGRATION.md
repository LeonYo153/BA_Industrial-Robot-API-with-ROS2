# Migration Notes

API changes in MoveIt Visual Tools releases

## ROS Melodic

- Affine3d no longer used, replaced by more computationally efficient Isometry3d. Simple find-replace should suffice
