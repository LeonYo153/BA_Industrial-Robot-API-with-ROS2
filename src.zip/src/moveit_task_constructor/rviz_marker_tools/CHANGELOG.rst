^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rviz_marker_tools
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.1.3 (2023-03-06)
------------------

0.1.2 (2023-02-24)
------------------
* Fix marker creation: allow zero scale for geometric shapes (`#430 <https://github.com/ros-planning/moveit_task_constructor/issues/430>`_)
* Contributors: Robert Haschke

0.1.1 (2023-02-15)
------------------

0.1.0 (2023-02-02)
------------------
* Initial release
* Contributors: Robert Haschke, Michael Görner
